export class User {
  name: string;
  surname: string;
  email: string;
  job: string;
  username: string;
  password: string;
  gender: string;
  jmbg: string;
  question: string;
  answer: string;
  type: string;
}
